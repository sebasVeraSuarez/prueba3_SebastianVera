
// let menu = "";

// do {
//     menu = Number(prompt("elija el numero del vuelo que desea tomar \n"))

//     switch (menu) {
//         case "1":
//             let cantidad1 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad1 <= 50){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }           

//         case "2":
//             let cantidad2 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad2 <= 50){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }           

//         case "3":
//             let cantidad3 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad3 <= 75){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }

//         case "4":
//             let cantidad4 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad4 <= 80){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }

//         case "5":
//             let cantidad5 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad5 <= 100){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }

//         case "6":
//             let cantidad6 = Number(prompt("¿cuantos vuelos desea reservar?"))
//             if(cantidad6 <= 100){
//                 return alert("Reserva exitosa")
//             } else {
//                 return alert("No se puede reservar mas de 50 pasajeros")
//             }
        
//         default :
//             alert("vuelo no existente")
//     }

// } while (menu != 7)

const reservas = document.getElementById("formularioReservas")

reservas.addEventListener("submit",() => {
    const opcion = document.getElementById("vuelo1").value;
    const opcion2 = document.getElementById("vuelo2").value;
    
})
