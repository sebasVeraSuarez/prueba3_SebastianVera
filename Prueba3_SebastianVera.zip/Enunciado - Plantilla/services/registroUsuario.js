const formulario = document.getElementById("formularioUsuario")


formulario.addEventListener("submit" , (e) => {
    e.preventDefault();
    const nombre = document.getElementById("nombre").value;
    const correo = document.getElementById("correo").value;
    const cumpleaños = document.getElementById("cumpleaños").value;
    const contraseña = document.getElementById("contraseña").value;

    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const usuarioRegistrado = usuarios.find(usuario => usuario.correo === correo);
    if (usuarioRegistrado) {
        return alert ("el usuario ya esta registrado")
    }

    usuarios.push({nombre: nombre, correo: correo, cumpleaños: cumpleaños, contraseña: contraseña});
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    alert("registro de usuario completado");
    window.location.href = "/views/reservas.html"
})