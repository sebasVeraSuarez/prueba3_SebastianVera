const formulario = document.getElementById("registerForm")


formulario.addEventListener("submit" , (e) => {
    e.preventDefault();
    const nombre = document.getElementById("name").value;
    const correo = document.getElementById("email").value;
    const cumpleaños = document.getElementById("dob").value;
    const contraseña = document.getElementById("password").value;

    const admins = JSON.parse(localStorage.getItem("admins")) || [];
    const adminRegistrado = admins.find(admin => admin.correo === correo);
    if (adminRegistrado) {
        return alert ("el usuario ya esta registrado")
    }

    admins.push({nombre: nombre, correo: correo, cumpleaños: cumpleaños, contraseña: contraseña});
    localStorage.setItem("admins", JSON.stringify(admins));
    alert("registro exitoso");
    window.location.href = "/views/login.html"
})


