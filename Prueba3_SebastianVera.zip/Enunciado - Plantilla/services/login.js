const formularioInicio = document.getElementById("loginForm");


formularioInicio.addEventListener("submit", (e) => {
    e.preventDefault();
    const correoInicio = document.getElementById("email1").value;
    const contraseñaInicio = document.getElementById("password1").value;
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const validarUsuario = usuarios.find(usuario => usuario.correo === correoInicio && usuario.contraseña === contraseñaInicio);
    if (! validarUsuario) {
        return alert("usuario o contraseña incorrectos")
    }
    alert("inicio de sesion exitoso")
    window.location.href = "/index.html"

})
